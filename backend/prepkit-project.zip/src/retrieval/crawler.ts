import * as cheerio from "cheerio";
import { isAllowedByRobots } from "./robots";
import { assertPublicHttpUrl } from "./urlSafety";

const MAX_PAGE_CHARS = 2_000_000; // ~2MB of HTML text, generous but bounded
const FETCH_TIMEOUT_MS = 8_000;
const MAX_CANDIDATES_TO_INSPECT = 5; // how many scored links we'll actually fetch and check

// Keywords alone are a weak signal (a footer often links to a generic
// "careers" page that's just a stub). We score by keyword + placement,
// then *confirm* the top candidates by looking for on-page evidence of a
// real hiring page before committing to one.
const HIRING_KEYWORDS = [
  "careers",
  "career",
  "jobs",
  "job",
  "hiring",
  "join us",
  "join-us",
  "work with us",
  "work at",
  "life at",
  "opportunities",
  "vacancy",
  "vacancies",
  "openings",
  "open positions",
  "employment",
];

// If a candidate page mentions/links one of these, it's very likely the
// real hiring page (companies almost always route applications through
// one of these ATS platforms rather than rolling their own).
const ATS_HOST_HINTS = [
  "greenhouse.io",
  "lever.co",
  "myworkdayjobs.com",
  "ashbyhq.com",
  "bamboohr.com",
  "smartrecruiters.com",
  "jobvite.com",
  "breezy.hr",
  "recruitee.com",
  "workable.com",
  "icims.com",
];

const ON_PAGE_SIGNALS = ["open position", "apply now", "view all jobs", "current openings", "job listing"];

export interface CrawlResult {
  hiringPageUrl: string | null;
  hiringPageText: string | null;
  /** Every URL actually fetched successfully — feeds source.pages_used in Appendix A. */
  pagesUsed: string[];
}

interface FetchedPage {
  html: string;
  finalUrl: string;
}

async function fetchPage(url: string): Promise<FetchedPage | null> {
  await assertPublicHttpUrl(url); // throws UnsafeUrlError — let it propagate, this is a hard stop

  if (!(await isAllowedByRobots(url))) return null;

  let res: Response;
  try {
    res = await fetch(url, {
      signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
      headers: { "User-Agent": "PrepKitBot/1.0 (+interview prep tool; respects robots.txt)" },
    });
  } catch {
    return null; // timeout, DNS failure, connection refused, etc. — treat as "couldn't get this page"
  }

  if (!res.ok) return null;

  const contentType = res.headers.get("content-type") || "";
  if (!contentType.includes("text/html")) return null;

  const html = await res.text();
  if (html.length > MAX_PAGE_CHARS) return null;

  return { html, finalUrl: res.url || url };
}

function scoreLink(href: string, anchorText: string, location: "nav" | "footer" | "body"): number {
  const haystack = `${href} ${anchorText}`.toLowerCase();
  let score = 0;
  for (const kw of HIRING_KEYWORDS) {
    if (haystack.includes(kw)) score += kw.length > 6 ? 3 : 2;
  }
  if (score === 0) return 0;
  if (location === "nav") score += 3;
  if (location === "footer") score += 1;

  const depth = new URL(href).pathname.split("/").filter(Boolean).length;
  if (depth <= 2) score += 2; // shallow paths are more likely top-level nav destinations

  return score;
}

function extractCandidateLinks(html: string, baseUrl: string): Array<{ url: string; score: number }> {
  const $ = cheerio.load(html);
  const origin = new URL(baseUrl).origin;
  const best = new Map<string, number>();

  const sections: Array<{ selector: string; location: "nav" | "footer" | "body" }> = [
    { selector: "nav a", location: "nav" },
    { selector: "header a", location: "nav" },
    { selector: "footer a", location: "footer" },
    { selector: "a", location: "body" },
  ];

  for (const { selector, location } of sections) {
    $(selector).each((_, el) => {
      const href = $(el).attr("href");
      if (!href) return;
      let abs: string;
      try {
        abs = new URL(href, baseUrl).toString();
      } catch {
        return;
      }
      if (!abs.startsWith(origin)) return; // same-origin only for the graph walk itself

      const text = $(el).text().trim();
      const score = scoreLink(abs, text, location);
      if (score > 0) {
        best.set(abs, Math.max(best.get(abs) ?? 0, score));
      }
    });
  }

  return [...best.entries()]
    .map(([url, score]) => ({ url, score }))
    .sort((a, b) => b.score - a.score);
}

function pageLooksLikeHiringPage(html: string): boolean {
  const lower = html.toLowerCase();
  const hasOnPageSignal = ON_PAGE_SIGNALS.some((s) => lower.includes(s));
  const linksToATS = ATS_HOST_HINTS.some((h) => lower.includes(h));
  return hasOnPageSignal || linksToATS;
}

/** Strips markup noise and collapses whitespace. Used for both graph-walk pages and the final hiring page text. */
export function cleanText(html: string): string {
  const $ = cheerio.load(html);
  $("script, style, noscript, svg, iframe").remove();
  return $("body").text().replace(/\s+/g, " ").trim();
}

/**
 * Finds a company's hiring/careers page from just its root URL — no
 * hardcoded path list. Strategy:
 *   1. Fetch the root page.
 *   2. If the root itself already looks like a hiring hub (small
 *      companies sometimes put openings right on the homepage), use it.
 *   3. Otherwise extract same-origin links, score them by keyword +
 *      placement (nav/footer beats a random body link) + shallow path.
 *   4. Fetch the top-scoring candidates and *confirm* each one by
 *      looking for actual hiring-page evidence (an ATS link, "open
 *      positions" language) before committing — a link merely
 *      containing the word "careers" isn't proof it goes anywhere useful.
 *   5. If nothing confirms, fall back to the single best-scored
 *      candidate rather than giving up outright.
 *   6. If even the root page can't be fetched, degrade to "not found"
 *      rather than throwing — downstream, the kit is generated with an
 *      empty company_brief and a note, not a crash.
 */
export async function findHiringPage(companyUrl: string): Promise<CrawlResult> {
  const pagesUsed: string[] = [];

  const root = await fetchPage(companyUrl);
  if (!root) {
    return { hiringPageUrl: null, hiringPageText: null, pagesUsed };
  }
  pagesUsed.push(root.finalUrl);

  if (pageLooksLikeHiringPage(root.html)) {
    return { hiringPageUrl: root.finalUrl, hiringPageText: cleanText(root.html), pagesUsed };
  }

  const candidates = extractCandidateLinks(root.html, root.finalUrl).slice(0, MAX_CANDIDATES_TO_INSPECT);

  let bestUnconfirmed: FetchedPage | null = null;

  for (const candidate of candidates) {
    const page = await fetchPage(candidate.url);
    if (!page) continue;
    pagesUsed.push(page.finalUrl);

    if (!bestUnconfirmed) bestUnconfirmed = page;

    if (pageLooksLikeHiringPage(page.html)) {
      return { hiringPageUrl: page.finalUrl, hiringPageText: cleanText(page.html), pagesUsed };
    }
  }

  if (bestUnconfirmed) {
    return {
      hiringPageUrl: bestUnconfirmed.finalUrl,
      hiringPageText: cleanText(bestUnconfirmed.html),
      pagesUsed,
    };
  }

  return { hiringPageUrl: null, hiringPageText: null, pagesUsed };
}
